﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Yan Ho Chan - 301008722 - Last Modified: 7/25/2019 - BMI Calculator
 */
namespace BMI_Calc
{
    public partial class BMICalculator : Form
    {
        private string result2;

        public BMICalculator()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            //declaring variables
            double weight = Convert.ToDouble(txtWeight.Text);
            double height = Convert.ToDouble(txtHeight.Text);
            double result = 0.0;
           
            //conditions to get result
            if(radKg.Checked)
            {
                result = weight / (height * height);
            }
            else
            if (radLb.Checked)
            {
                weight = weight / 2.205;
                result = weight / (height * height);
            }
            if (result < 18.5)
            {
                result2 = "You are underweight";
            }
            else
            if (result < 25)
            {
                result2 = "You are normal weight";
            }
            else
            if (result < 30)
            {
                result2 = "Your are overweight";
            }
            else
            if (result >= 30)
                result2 = "You are obese";
            
            //outputs result
            txtResult.Text = "Your BMI is: " + result.ToString("#.#") + "\r\n" + result2;

            textBox4.Text = result.ToString("#.#");
            

        }

        private void btnExit_Click(object sender, EventArgs e)
         //closes application
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
         //resetting values
        {
            txtHeight.Text = "";
            txtWeight.Text = "";
            txtResult.Text = "";

            radKg.Checked = false;
            radLb.Checked = false;
        }


    }
}
